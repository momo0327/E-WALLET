import Card from "./Card"
import { useDispatch } from 'react-redux';
import { Add } from '../assets/redux/action';
import { Active } from '../assets/redux/action';
import reducer from '../assets/redux/reducer';

   


function CardStack(props) {
    const dispatch = useDispatch()


    const content = props.storeCard.map((card)=> {
        return <Card info = {card} />
    })

    return (
        <div>
            <div >{content}</div>
        </div>

        
    )
}

export default CardStack