function Top () {
    return(
        <div>
            <h1 className="big-title">ADD A NEW BANK CARD</h1>
        </div>
     
    )
}

export default Top