import './App.css'
import Addcard from './pages/AddCard'
import './components/style.css'
import {RouterProvider,createBrowserRouter} from 'react-router-dom'
import Home from './pages/Home'



function App() {
  const router = createBrowserRouter([{

    path: '/',
    element: <Home />
  },
  {
    path: '/addcard',
    element: <Addcard />
  }])
  

  return (
    <div className="App">
     

    <RouterProvider router = {router}/>

    </div>
  )
}

export default App
