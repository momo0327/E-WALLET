function Add (value) {
    return{
        type: 'ADD',
        payload: value
    }
}

function Active(value) {
    return{
        type:'ACTIVE',
        payload: value
    }
}
// en till funktion ör activet kort

export {Add}
export {Active}