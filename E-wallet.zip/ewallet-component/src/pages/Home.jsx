
import { useNavigate } from "react-router-dom";
import {useSelector} from "react-redux";
import CardStack from "../components/Cardstack";
import  '../components/style.css'
import Card from "../components/Card";





function Home() {
    const navigate = useNavigate()


 const storeCard = useSelector((state) => {
    return state.cards
    
 })
 const ActivCard = useSelector((state) => {
    return state.activeCards
    
 })

 


    function handleClick() {
        navigate('/addCard')
    }

 
   

    return (
        <div className="home-body">
            <h1 className="big-title">   E-WALLET</h1>
            <p>Activ Card</p>
            <Card  info={ActivCard} key={99}/>
            
       
            <CardStack storeCard = {storeCard}/>

       

        <button onClick={handleClick}>ADD CARD</button>
        </div>
        
    )
}

export default Home