
import { useNavigate } from "react-router-dom";
import {useSelector} from "react-redux";
import CardStack from "../components/Cardstack";
import { Active } from "../assets/redux/action";
import  '../components/style.css'





function Home() {
    const navigate = useNavigate()


 const storeCard = useSelector((state) => {
    return state.cards
    
 })

 

 console.log(storeCard)

    function handleClick() {
        navigate('/addCard')
    }

 
   

    return (
        <div className="home-body">
            <h1 className="big-title">   E-WALLET</h1>
            
        <CardStack storeCard = {storeCard}/>
        
       

        <button onClick={handleClick}>ADD CARD</button>
        </div>
        
    )
}

export default Home