import CardForm from "../components/CardForm"
import Card from "../components/Card"
import '../components/style.css'
import Top from "../components/Top"

function Addcard() {
    return(
        <div>

        <div className="form-body">
            <article className="title">
            <Top/>
            </article>
            <div className="form-top">
            <Card/>
            </div>
            <div className="form-bottom">
            <CardForm/>

            </div>
        
        </div>
        </div>
       
    )
}

export default Addcard