import './style.css'
import { useState } from 'react'
import { useDispatch } from 'react-redux';
import { Add } from '../assets/redux/action';
import { Active } from '../assets/redux/action';
import reducer from '../assets/redux/reducer';
import { useNavigate } from 'react-router-dom';


function CardForm () {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const [number, setNumber] = useState()
    const [name, setName] = useState()
    const [date, setDate] = useState()
    const [ccv, setCcv] = useState()
    const [vendor, setVendor] = useState()
    

    let creditCard =  {
        number: number,  // det är en variabel som definerar usestate variabeln
        name: name,
        date: date,
        ccv: ccv,
        vendor: vendor
    }


  

    function handleClick() {
        
        console.log(creditCard)
        dispatch(Add(creditCard))
        navigate('/')
    }


   



    return(
            <section className='form'>
               
                <input className='number'placeholder ='Card number' name='number' onChange={(event)=> setNumber(event.target.value)} type="numbers" maxLength={18}/>
                <br />
                <br />
                <input className='name' placeholder ='First name' name='name' type="text"   onChange={(event)=> setName(event.target.value)}/>
                <br />
                <br />
                <div className='small-box'>
                    <input className='date' placeholder ='Valid thru'  name='date' type="date"   onChange={(event)=> setDate(event.target.value)}/>
                    <br />
                    <br />
                    
                    <input className='ccv'placeholder ='CCV' type="numbers" name='ccv' maxLength={3}  onChange={(event)=> setCcv(event.target.value)}/>
                </div>
                
                <br />
                <div>

                <select className='vendor' placeholder="vendor" name="vendor"  onChange={(event)=> setVendor(event.target.value)} >
                    <option value="">Vendor</option>
                    <option value="bitcoin">bitcoin</option>
                    <option value="blockchain">blockchain</option>
                    <option value="evil">evil</option>
                    <option value="ninja">ninja</option>
                </select>
                </div>
                <br />
               
                <button onClick={handleClick}>ADD CARD</button>

             


            </section>
    
        
    )
}

export default CardForm