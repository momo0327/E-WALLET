import './style.css'

import bitcoin from '../svgs/vendor-bitcoin.svg'
import ninja from '../svgs/vendor-ninja.svg'
import blockchain from '../svgs/vendor-blockchain.svg'
import evil from '../svgs/vendor-evil.svg'
import { Active } from '../assets/redux/action'
import { useDispatch } from 'react-redux';
import light from '../svgs/chip-light.svg'
import dark from '../svgs/chip-dark.svg'
import { useState } from 'react'






function Card(props) {
   
    const dispatch = useDispatch()

    const pickvendor = [ninja, blockchain, evil, bitcoin,]
    let imgVendor ;

    let diffChip = [dark, light]
    let chip ;

    let color ;
    let diffColor = ['card-body-red', 'card-body-purple', 'card-body-black', 'card-body-yellow']


    


    if (
        props?.info?.vendor === 'ninja' 
    ){
        imgVendor = pickvendor[0]
        chip = diffChip[1]
        color = diffColor[2]
    }

    if (
        props?.info?.vendor === 'bitcoin'
    ){
        imgVendor = pickvendor[3]
        chip = diffChip[0]
        color = diffColor[3]


    }

    if (
        props?.info?.vendor === 'blockchain'
    ){
        imgVendor = pickvendor[1]
        chip = diffChip[1]
        color = diffColor[1]


    }

    if (
        props?.info?.vendor === 'evil'
    ){
        imgVendor = pickvendor[2]
        chip = diffChip[1]
        color = diffColor[0]


    } else {
        chip = diffChip[0]
    }


console.log(Active)
   
    return(
        <div >

        <article onClick={(event)=> {
            event(dispatch(Active()))
        }} className=  {`card-body ${color}` }>
            <div className='top'>
                <img className='chip' src={chip} alt="" />                
                <img className='vendorImg' src={ imgVendor} alt="" />                
            </div>
            <div>
                <div className='bottom'>
                    <div>
                    <p className='numbers'> {props?.info?.number || 'XXXX XXXX XXXX XXXX'}</p>
                    </div>
                    <div className='Lname'> 
                        <div>
                        <p className='fnamelname'>{props?.info?.name || 'FIRSTNAME LASTNAME'} </p>


                        </div>
                    <p className='dateCard'>{props?.info?.date || 'MM/YY'}</p>
                    </div>
                 
                </div>
               
              

            </div>
            
       </article>

       <br />
       <br />
       
       </div>

    )


}


export default Card