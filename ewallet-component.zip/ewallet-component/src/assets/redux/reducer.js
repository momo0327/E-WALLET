const initialState = {
    cards: [],
    activeCards: []

}

const reducer = (state = initialState, action) => {
    switch(action.type ) {
        case 'ADD':
            return {
                ...state, cards: [...state.cards, action.payload]
            }
        case 'ACTIVE':
            return{
                ...state, activeCards: [...state.activeCards,action.payload]
            }
            default:
                return state
                

    }
}

export default reducer


// active cards _>  när den klcikas ska kortet läggas till i active card arrayen i reducern och detta gör jag med att skapa en case i reducer och en funvtion i action och klick event i card